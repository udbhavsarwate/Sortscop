import { useState } from 'react'
import { Header } from '@/components/Header'
import { VisualizePage } from '@/pages/VisualizePage'
import { ComparisonMode } from '@/components/ComparisonMode'
import { ErrorBoundary } from '@/components/ErrorBoundary'
import { useThemeEffect } from '@/hooks/useThemeEffect'

function App() {
  const [view, setView] = useState<'visualize' | 'compare'>('visualize')
  useThemeEffect()

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-[var(--bg)] text-[var(--text)]">
        <Header view={view} setView={setView} />
        <div className="mx-auto max-w-7xl px-6 py-6">
          {view === 'visualize' ? <VisualizePage /> : <ComparisonMode />}
        </div>
        <footer className="mx-auto max-w-7xl px-6 pb-8 pt-2 text-center text-xs text-[var(--text-dim)]">
          Built with React, TypeScript, Tailwind CSS, Framer Motion, and Zustand.
        </footer>
      </div>
    </ErrorBoundary>
  )
}

export default App
