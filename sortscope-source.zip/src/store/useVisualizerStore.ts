import { create } from 'zustand'
import { sortFunctions, type AlgorithmId, type SortStep } from '@/algorithms'
import type { ThemeId } from '@/constants/themes'
import { THEME_ORDER } from '@/constants/themes'
import { recordRun } from './useStatsStore'

export type PlaybackStatus = 'idle' | 'playing' | 'paused' | 'done'

interface Highlights {
  compare: number[]
  swap: number[]
  sorted: Set<number>
  pivot: number[]
  current: number[]
  merge: number[]
}

const emptyHighlights = (): Highlights => ({
  compare: [],
  swap: [],
  sorted: new Set(),
  pivot: [],
  current: [],
  merge: [],
})

interface VisualizerState {
  array: number[]
  arraySize: number
  speed: number // 1 (slow) - 100 (fast)
  algorithm: AlgorithmId
  theme: ThemeId
  status: PlaybackStatus
  steps: SortStep[]
  stepIndex: number
  highlights: Highlights
  comparisons: number
  swaps: number
  totalComparisons: number
  totalSwaps: number
  elapsedMs: number
  startedAt: number | null
  timerId: number | null

  setTheme: (t: ThemeId) => void
  cycleTheme: () => void
  setAlgorithm: (a: AlgorithmId) => void
  setArraySize: (n: number) => void
  setSpeed: (s: number) => void
  generateRandomArray: (size?: number) => void
  shuffleArray: () => void
  reverseArray: () => void
  nearlySortedArray: () => void
  setCustomArray: (values: number[]) => void
  prepareSteps: () => void
  play: () => void
  pause: () => void
  resume: () => void
  stop: () => void
  reset: () => void
  _tick: () => void
}

function randomArray(size: number, min = 5, max = 400): number[] {
  return Array.from({ length: size }, () => Math.floor(Math.random() * (max - min + 1)) + min)
}

function speedToDelayMs(speed: number): number {
  // speed 1 -> slow (500ms), speed 100 -> fast (2ms)
  const clamped = Math.min(100, Math.max(1, speed))
  const t = (clamped - 1) / 99
  return Math.round(500 - t * 498)
}

export const useVisualizerStore = create<VisualizerState>((set, get) => ({
  array: randomArray(40),
  arraySize: 40,
  speed: 60,
  algorithm: 'merge',
  theme: 'signal',
  status: 'idle',
  steps: [],
  stepIndex: 0,
  highlights: emptyHighlights(),
  comparisons: 0,
  swaps: 0,
  totalComparisons: 0,
  totalSwaps: 0,
  elapsedMs: 0,
  startedAt: null,
  timerId: null,

  setTheme: (t) => set({ theme: t }),
  cycleTheme: () => {
    const idx = THEME_ORDER.indexOf(get().theme)
    const next = THEME_ORDER[(idx + 1) % THEME_ORDER.length]
    set({ theme: next })
  },
  setAlgorithm: (a) => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    set({
      algorithm: a,
      status: 'idle',
      steps: [],
      stepIndex: 0,
      highlights: emptyHighlights(),
      comparisons: 0,
      swaps: 0,
      elapsedMs: 0,
      timerId: null,
    })
  },
  setArraySize: (n) => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    set({ arraySize: n, array: randomArray(n), status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, timerId: null })
  },
  setSpeed: (sp) => set({ speed: sp }),

  generateRandomArray: (size) => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    const n = size ?? s.arraySize
    set({ array: randomArray(n), status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, timerId: null })
  },
  shuffleArray: () => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    const arr = [...s.array]
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[arr[i], arr[j]] = [arr[j], arr[i]]
    }
    set({ array: arr, status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, timerId: null })
  },
  reverseArray: () => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    const sorted = [...s.array].sort((a, b) => b - a)
    set({ array: sorted, status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, timerId: null })
  },
  nearlySortedArray: () => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    const arr = [...s.array].sort((a, b) => a - b)
    const swapsToMake = Math.max(1, Math.floor(arr.length * 0.05))
    for (let k = 0; k < swapsToMake; k++) {
      const i = Math.floor(Math.random() * arr.length)
      const j = Math.floor(Math.random() * arr.length)
      ;[arr[i], arr[j]] = [arr[j], arr[i]]
    }
    set({ array: arr, status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, timerId: null })
  },
  setCustomArray: (values) => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    set({ array: values, arraySize: values.length, status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, timerId: null })
  },

  prepareSteps: () => {
    const { array, algorithm } = get()
    const result = sortFunctions[algorithm](array)
    set({ steps: result.steps, stepIndex: 0, totalComparisons: result.comparisons, totalSwaps: result.swaps })
  },

  play: () => {
    const s = get()
    if (s.status === 'playing') return
    let steps = s.steps
    if (steps.length === 0 || s.status === 'done') {
      const result = sortFunctions[s.algorithm](s.array)
      steps = result.steps
      set({ steps, stepIndex: 0, totalComparisons: result.comparisons, totalSwaps: result.swaps, comparisons: 0, swaps: 0, highlights: emptyHighlights(), startedAt: Date.now() })
    } else if (s.startedAt === null) {
      set({ startedAt: Date.now() })
    }
    set({ status: 'playing' })
    get()._tick()
  },
  pause: () => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    set({ status: 'paused', timerId: null })
  },
  resume: () => {
    const s = get()
    if (s.status !== 'paused') return
    set({ status: 'playing' })
    get()._tick()
  },
  stop: () => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    set({ status: 'idle', stepIndex: 0, steps: [], highlights: emptyHighlights(), comparisons: 0, swaps: 0, elapsedMs: 0, startedAt: null, timerId: null })
  },
  reset: () => {
    const s = get()
    if (s.timerId) window.clearTimeout(s.timerId)
    set({ array: randomArray(s.arraySize), status: 'idle', steps: [], stepIndex: 0, highlights: emptyHighlights(), comparisons: 0, swaps: 0, elapsedMs: 0, startedAt: null, timerId: null })
  },

  _tick: () => {
    const s = get()
    if (s.status !== 'playing') return
    if (s.stepIndex >= s.steps.length) {
      const elapsed = s.startedAt ? Date.now() - s.startedAt : 0
      set({ status: 'done', elapsedMs: elapsed, highlights: { ...s.highlights, sorted: new Set(s.array.map((_, i) => i)) } })
      recordRun(s.algorithm, s.arraySize, elapsed)
      return
    }
    const step = s.steps[s.stepIndex]
    const h = emptyHighlights()
    h.sorted = new Set(s.highlights.sorted)
    let comparisons = s.comparisons
    let swaps = s.swaps
    let array = s.array

    switch (step.kind) {
      case 'compare':
        h.compare = step.indices
        comparisons++
        break
      case 'swap':
        h.swap = step.indices
        swaps++
        if (step.array) array = step.array
        break
      case 'overwrite':
        h.current = step.indices
        if (step.array) array = step.array
        break
      case 'merge':
        h.merge = step.indices
        if (step.array) array = step.array
        break
      case 'pivot':
        h.pivot = step.indices
        break
      case 'current':
      case 'heap':
        h.current = step.indices
        break
      case 'sorted':
        step.indices.forEach((i) => h.sorted.add(i))
        break
      case 'range':
      case 'done':
        break
    }

    const delay = speedToDelayMs(s.speed)
    const timerId = window.setTimeout(() => {
      get()._tick()
    }, delay)

    set({ highlights: h, comparisons, swaps, array, stepIndex: s.stepIndex + 1, timerId })
  },
}))
