import { create } from 'zustand'
import type { AlgorithmId } from '@/algorithms/types'

const STORAGE_KEY = 'sorting-visualizer-stats-v1'

export interface RunStats {
  algorithmsExecuted: Record<string, number>
  totalArraysSorted: number
  largestArraySorted: number
  fastestExecutionMs: number | null
  totalExecutionMs: number
  executionCount: number
}

function defaultStats(): RunStats {
  return {
    algorithmsExecuted: {},
    totalArraysSorted: 0,
    largestArraySorted: 0,
    fastestExecutionMs: null,
    totalExecutionMs: 0,
    executionCount: 0,
  }
}

function loadStats(): RunStats {
  if (typeof window === 'undefined') return defaultStats()
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return defaultStats()
    const parsed = JSON.parse(raw)
    return { ...defaultStats(), ...parsed }
  } catch {
    return defaultStats()
  }
}

function saveStats(stats: RunStats) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(stats))
  } catch {
    // localStorage unavailable — stats simply won't persist this session
  }
}

interface StatsState {
  stats: RunStats
  clear: () => void
}

export const useStatsStore = create<StatsState>((set) => ({
  stats: loadStats(),
  clear: () => {
    const fresh = defaultStats()
    saveStats(fresh)
    set({ stats: fresh })
  },
}))

export function recordRun(algorithm: AlgorithmId, arraySize: number, elapsedMs: number) {
  const current = useStatsStore.getState().stats
  const next: RunStats = {
    algorithmsExecuted: {
      ...current.algorithmsExecuted,
      [algorithm]: (current.algorithmsExecuted[algorithm] ?? 0) + 1,
    },
    totalArraysSorted: current.totalArraysSorted + 1,
    largestArraySorted: Math.max(current.largestArraySorted, arraySize),
    fastestExecutionMs:
      current.fastestExecutionMs === null ? elapsedMs : Math.min(current.fastestExecutionMs, elapsedMs),
    totalExecutionMs: current.totalExecutionMs + elapsedMs,
    executionCount: current.executionCount + 1,
  }
  saveStats(next)
  useStatsStore.setState({ stats: next })
}

export function favoriteAlgorithm(stats: RunStats): string | null {
  const entries = Object.entries(stats.algorithmsExecuted)
  if (entries.length === 0) return null
  return entries.sort((a, b) => b[1] - a[1])[0][0]
}
