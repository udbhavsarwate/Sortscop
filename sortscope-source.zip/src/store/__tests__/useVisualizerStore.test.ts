import { describe, it, expect, beforeEach } from 'vitest'
import { useVisualizerStore } from '@/store/useVisualizerStore'

describe('useVisualizerStore', () => {
  beforeEach(() => {
    useVisualizerStore.getState().stop()
    useVisualizerStore.setState({ arraySize: 20, algorithm: 'merge', speed: 60 })
    useVisualizerStore.getState().generateRandomArray(20)
  })

  it('generates an array of the requested size within the expected value range', () => {
    useVisualizerStore.getState().generateRandomArray(30)
    const { array } = useVisualizerStore.getState()
    expect(array).toHaveLength(30)
    array.forEach((v) => {
      expect(v).toBeGreaterThanOrEqual(5)
      expect(v).toBeLessThanOrEqual(400)
    })
  })

  it('setArraySize updates arraySize and regenerates the array to match', () => {
    useVisualizerStore.getState().setArraySize(50)
    const { arraySize, array } = useVisualizerStore.getState()
    expect(arraySize).toBe(50)
    expect(array).toHaveLength(50)
  })

  it('reverseArray produces a descending array', () => {
    useVisualizerStore.getState().reverseArray()
    const { array } = useVisualizerStore.getState()
    for (let i = 1; i < array.length; i++) {
      expect(array[i - 1]).toBeGreaterThanOrEqual(array[i])
    }
  })

  it('setCustomArray applies exactly the provided values', () => {
    useVisualizerStore.getState().setCustomArray([9, 1, 5, 3])
    const { array, arraySize } = useVisualizerStore.getState()
    expect(array).toEqual([9, 1, 5, 3])
    expect(arraySize).toBe(4)
  })

  it('setAlgorithm switches the active algorithm and resets playback status', () => {
    useVisualizerStore.getState().setAlgorithm('quick')
    const { algorithm, status, stepIndex } = useVisualizerStore.getState()
    expect(algorithm).toBe('quick')
    expect(status).toBe('idle')
    expect(stepIndex).toBe(0)
  })

  it('prepareSteps computes a non-empty step list and matching totals', () => {
    useVisualizerStore.getState().setCustomArray([5, 3, 4, 1, 2])
    useVisualizerStore.getState().prepareSteps()
    const { steps, totalComparisons } = useVisualizerStore.getState()
    expect(steps.length).toBeGreaterThan(0)
    expect(totalComparisons).toBeGreaterThan(0)
  })

  it('stop resets playback state back to idle with zeroed counters', () => {
    useVisualizerStore.getState().prepareSteps()
    useVisualizerStore.getState().play()
    useVisualizerStore.getState().stop()
    const { status, comparisons, swaps, stepIndex } = useVisualizerStore.getState()
    expect(status).toBe('idle')
    expect(comparisons).toBe(0)
    expect(swaps).toBe(0)
    expect(stepIndex).toBe(0)
  })
})
