import { useEffect, useState } from 'react'
import { useVisualizerStore } from '@/store/useVisualizerStore'
import { ALGORITHM_INFO } from '@/constants/algorithmInfo'

function StatCell({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5">
      <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--text-dim)]">{label}</div>
      <div className="font-mono text-lg font-medium text-[var(--text)]">{value}</div>
    </div>
  )
}

export function StatsDashboard() {
  const { comparisons, swaps, arraySize, algorithm, status, startedAt } = useVisualizerStore()
  const [liveMs, setLiveMs] = useState(0)

  useEffect(() => {
    if (status !== 'playing' || !startedAt) return
    const id = window.setInterval(() => setLiveMs(Date.now() - startedAt), 33)
    return () => window.clearInterval(id)
  }, [status, startedAt])

  const elapsed = status === 'done' && startedAt ? liveMs : status === 'playing' ? liveMs : 0
  const estMemory = arraySize * 8 // bytes, rough estimate for a numeric array

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5">
      <h3 className="mb-3 font-display text-sm font-semibold text-[var(--text)]">Performance dashboard</h3>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
        <StatCell label="Algorithm" value={ALGORITHM_INFO[algorithm].name} />
        <StatCell label="Comparisons" value={comparisons.toLocaleString()} />
        <StatCell label="Swaps / writes" value={swaps.toLocaleString()} />
        <StatCell label="Array size" value={arraySize} />
        <StatCell label="Time elapsed" value={`${elapsed} ms`} />
        <StatCell label="Est. memory" value={`${estMemory} B`} />
      </div>
    </div>
  )
}
