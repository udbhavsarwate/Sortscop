import { useState } from 'react'
import { useVisualizerStore } from '@/store/useVisualizerStore'

export function CustomArrayInput() {
  const setCustomArray = useVisualizerStore((s) => s.setCustomArray)
  const status = useVisualizerStore((s) => s.status)
  const [text, setText] = useState('')
  const [error, setError] = useState<string | null>(null)
  const isBusy = status === 'playing' || status === 'paused'

  function handleApply() {
    const parts = text
      .split(/[,\s]+/)
      .map((p) => p.trim())
      .filter(Boolean)

    if (parts.length < 2) {
      setError('Enter at least 2 numbers, separated by commas or spaces.')
      return
    }
    if (parts.length > 200) {
      setError('Keep custom arrays to 200 values or fewer.')
      return
    }
    const values = parts.map(Number)
    if (values.some((v) => Number.isNaN(v))) {
      setError('Only numeric values are allowed.')
      return
    }
    if (values.some((v) => v < 0 || v > 1000)) {
      setError('Values must be between 0 and 1000.')
      return
    }
    setError(null)
    setCustomArray(values)
  }

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5">
      <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">
        Custom array
      </label>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        disabled={isBusy}
        placeholder="e.g. 42, 17, 88, 3, 56, 9"
        rows={2}
        className="focus-ring w-full resize-none rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 font-mono text-sm text-[var(--text)] placeholder:text-[var(--text-dim)] disabled:opacity-50"
      />
      {error && <p className="mt-1.5 text-xs text-[var(--swap)]">{error}</p>}
      <button
        onClick={handleApply}
        disabled={isBusy}
        className="focus-ring mt-2 w-full rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm font-medium text-[var(--text)] transition hover:border-[var(--accent)] hover:text-[var(--accent)] disabled:cursor-not-allowed disabled:opacity-40"
      >
        Apply custom array
      </button>
    </div>
  )
}
