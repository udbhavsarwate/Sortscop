import { useMemo, useState } from 'react'
import { FiPlay } from 'react-icons/fi'
import { ALGORITHM_INFO, ALGORITHM_ORDER } from '@/constants/algorithmInfo'
import type { AlgorithmId } from '@/algorithms/types'
import { useSortPlayer } from '@/hooks/useSortPlayer'
import { resolveBarColor } from '@/utils/barColor'

function randomArray(size: number): number[] {
  return Array.from({ length: size }, () => Math.floor(Math.random() * 380) + 10)
}

function Panel({ algorithm, array, speed }: { algorithm: AlgorithmId; array: number[]; speed: number }) {
  const { array: liveArray, highlights, comparisons, swaps, status, elapsedMs, play } = useSortPlayer(algorithm, array, speed)
  const maxVal = Math.max(...liveArray, 1)

  return (
    <div className="flex-1 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-sm font-semibold text-[var(--text)]">{ALGORITHM_INFO[algorithm].name}</h3>
        <button
          onClick={play}
          disabled={status === 'playing'}
          className="focus-ring flex items-center gap-1 rounded-md border border-[var(--border)] px-2 py-1 text-xs text-[var(--text-dim)] hover:text-[var(--accent)] disabled:opacity-40"
        >
          <FiPlay /> Run
        </button>
      </div>
      <div className="mb-3 flex h-40 items-end gap-[1px] rounded-lg border border-[var(--border)] bg-[var(--surface-2)] p-2">
        {liveArray.map((v, i) => (
          <div
            key={i}
            className="flex-1 rounded-t-sm transition-all duration-150"
            style={{ height: `${(v / maxVal) * 100}%`, background: resolveBarColor(i, highlights), minWidth: 1 }}
          />
        ))}
      </div>
      <div className="grid grid-cols-3 gap-2 text-center text-xs">
        <div>
          <div className="text-[var(--text-dim)]">Comparisons</div>
          <div className="font-mono text-[var(--text)]">{comparisons}</div>
        </div>
        <div>
          <div className="text-[var(--text-dim)]">Swaps</div>
          <div className="font-mono text-[var(--text)]">{swaps}</div>
        </div>
        <div>
          <div className="text-[var(--text-dim)]">Time</div>
          <div className="font-mono text-[var(--text)]">{status === 'done' ? `${elapsedMs} ms` : '—'}</div>
        </div>
      </div>
    </div>
  )
}

export function ComparisonMode() {
  const [size, setSize] = useState(30)
  const [speed, setSpeed] = useState(70)
  const [seedArray, setSeedArray] = useState<number[]>(() => randomArray(30))
  const [left, setLeft] = useState<AlgorithmId>('merge')
  const [right, setRight] = useState<AlgorithmId>('quick')
  const [runKey, setRunKey] = useState(0)

  const array = useMemo(() => seedArray, [seedArray])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4">
        <select
          value={left}
          onChange={(e) => setLeft(e.target.value as AlgorithmId)}
          className="focus-ring rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm text-[var(--text)]"
        >
          {ALGORITHM_ORDER.map((id) => (
            <option key={id} value={id}>
              {ALGORITHM_INFO[id].name}
            </option>
          ))}
        </select>
        <span className="text-sm text-[var(--text-dim)]">vs</span>
        <select
          value={right}
          onChange={(e) => setRight(e.target.value as AlgorithmId)}
          className="focus-ring rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm text-[var(--text)]"
        >
          {ALGORITHM_ORDER.map((id) => (
            <option key={id} value={id}>
              {ALGORITHM_INFO[id].name}
            </option>
          ))}
        </select>

        <label className="ml-auto flex items-center gap-2 text-xs text-[var(--text-dim)]">
          Size
          <input
            type="range"
            min={10}
            max={100}
            value={size}
            onChange={(e) => setSize(Number(e.target.value))}
            className="accent-[var(--accent)]"
          />
          <span className="font-mono text-[var(--text)]">{size}</span>
        </label>
        <label className="flex items-center gap-2 text-xs text-[var(--text-dim)]">
          Speed
          <input
            type="range"
            min={1}
            max={100}
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="accent-[var(--accent)]"
          />
        </label>
        <button
          onClick={() => {
            setSeedArray(randomArray(size))
            setRunKey((k) => k + 1)
          }}
          className="focus-ring rounded-lg bg-[var(--accent)] px-3 py-2 text-sm font-medium text-[var(--bg)]"
        >
          New race array
        </button>
      </div>

      <div className="flex flex-col gap-4 md:flex-row" key={runKey}>
        <Panel algorithm={left} array={array} speed={speed} />
        <Panel algorithm={right} array={array} speed={speed} />
      </div>
    </div>
  )
}
