import { motion } from 'framer-motion'
import { useMemo } from 'react'
import { useVisualizerStore } from '@/store/useVisualizerStore'
import { resolveBarColor } from '@/utils/barColor'

export function BarChart() {
  const array = useVisualizerStore((s) => s.array)
  const highlights = useVisualizerStore((s) => s.highlights)
  const status = useVisualizerStore((s) => s.status)

  const maxVal = useMemo(() => Math.max(...array, 1), [array])
  const showValues = array.length <= 24

  return (
    <div className="relative flex h-full w-full items-end gap-[2px] rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 overflow-hidden">
      {array.map((value, i) => {
        const heightPct = (value / maxVal) * 100
        const color = resolveBarColor(i, highlights)
        return (
          <motion.div
            key={i}
            layout
            className="flex-1 rounded-t-sm relative"
            style={{ background: color, minWidth: 2 }}
            initial={false}
            animate={{ height: `${heightPct}%`, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30, mass: 0.5 }}
          >
            {showValues && (
              <span
                className="absolute -top-5 left-1/2 -translate-x-1/2 font-mono text-[10px]"
                style={{ color: 'var(--text-dim)' }}
              >
                {value}
              </span>
            )}
          </motion.div>
        )
      })}
      {status === 'idle' && array.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center text-[var(--text-dim)]">
          Generate an array to begin
        </div>
      )}
    </div>
  )
}
