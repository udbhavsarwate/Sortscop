import { FiDroplet } from 'react-icons/fi'
import { THEMES, THEME_ORDER } from '@/constants/themes'
import { useVisualizerStore } from '@/store/useVisualizerStore'

export function ThemeSwitcher() {
  const theme = useVisualizerStore((s) => s.theme)
  const setTheme = useVisualizerStore((s) => s.setTheme)

  return (
    <div className="focus-ring flex items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-2.5 py-1.5">
      <FiDroplet className="text-[var(--text-dim)]" />
      <select
        value={theme}
        onChange={(e) => setTheme(e.target.value as typeof theme)}
        className="bg-transparent text-sm text-[var(--text)] focus:outline-none"
      >
        {THEME_ORDER.map((id) => (
          <option key={id} value={id}>
            {THEMES[id].label}
          </option>
        ))}
      </select>
    </div>
  )
}
