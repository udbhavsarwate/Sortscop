const ITEMS = [
  { color: 'var(--bar)', label: 'Unsorted' },
  { color: 'var(--accent)', label: 'Current' },
  { color: 'var(--compare)', label: 'Comparing' },
  { color: 'var(--swap)', label: 'Swapping' },
  { color: 'var(--pivot)', label: 'Pivot' },
  { color: 'var(--accent-2)', label: 'Merging' },
  { color: 'var(--sorted)', label: 'Sorted' },
]

export function Legend() {
  return (
    <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-[var(--text-dim)]">
      {ITEMS.map((item) => (
        <div key={item.label} className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: item.color }} />
          {item.label}
        </div>
      ))}
    </div>
  )
}
