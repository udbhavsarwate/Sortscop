import { TbWaveSquare } from 'react-icons/tb'
import { ThemeSwitcher } from './ThemeSwitcher'

export function Header({ view, setView }: { view: 'visualize' | 'compare'; setView: (v: 'visualize' | 'compare') => void }) {
  return (
    <header className="flex items-center justify-between border-b border-[var(--border)] bg-[var(--surface)]/80 px-6 py-4 backdrop-blur">
      <div className="flex items-center gap-2.5">
        <TbWaveSquare className="text-2xl text-[var(--accent)]" />
        <div>
          <h1 className="font-display text-base font-semibold leading-tight text-[var(--text)]">Sortscope</h1>
          <p className="text-[11px] leading-tight text-[var(--text-dim)]">Sorting algorithm visualizer</p>
        </div>
      </div>

      <nav className="flex items-center gap-1 rounded-lg border border-[var(--border)] bg-[var(--surface-2)] p-1">
        <button
          onClick={() => setView('visualize')}
          className={`focus-ring rounded-md px-3 py-1.5 text-sm font-medium transition ${
            view === 'visualize' ? 'bg-[var(--accent)] text-[var(--bg)]' : 'text-[var(--text-dim)] hover:text-[var(--text)]'
          }`}
        >
          Visualize
        </button>
        <button
          onClick={() => setView('compare')}
          className={`focus-ring rounded-md px-3 py-1.5 text-sm font-medium transition ${
            view === 'compare' ? 'bg-[var(--accent)] text-[var(--bg)]' : 'text-[var(--text-dim)] hover:text-[var(--text)]'
          }`}
        >
          Compare
        </button>
      </nav>

      <ThemeSwitcher />
    </header>
  )
}
