import { useState } from 'react'
import { FiCopy, FiCheck } from 'react-icons/fi'
import { highlightLine } from '@/utils/highlight'
import type { AlgorithmMeta } from '@/constants/algorithmInfo'

const LANGS = [
  { id: 'javascript', label: 'JavaScript' },
  { id: 'python', label: 'Python' },
  { id: 'java', label: 'Java' },
  { id: 'cpp', label: 'C++' },
] as const

type LangId = (typeof LANGS)[number]['id']

export function CodeViewer({ meta }: { meta: AlgorithmMeta }) {
  const [lang, setLang] = useState<LangId>('javascript')
  const [copied, setCopied] = useState(false)
  const code = meta.code[lang]

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // clipboard unavailable; ignore silently
    }
  }

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)]">
      <div className="flex items-center justify-between border-b border-[var(--border)] px-4 py-2.5">
        <div className="flex gap-1">
          {LANGS.map((l) => (
            <button
              key={l.id}
              onClick={() => setLang(l.id)}
              className={`focus-ring rounded-md px-2.5 py-1 text-xs font-medium transition ${
                lang === l.id
                  ? 'bg-[var(--accent)] text-[var(--bg)]'
                  : 'text-[var(--text-dim)] hover:text-[var(--text)]'
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
        <button
          onClick={handleCopy}
          className="focus-ring flex items-center gap-1.5 rounded-md px-2 py-1 text-xs text-[var(--text-dim)] hover:text-[var(--accent)]"
        >
          {copied ? <FiCheck /> : <FiCopy />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed">
        <code>
          {code.split('\n').map((line, i) => (
            <div key={i} className="table-row">
              <span className="table-cell select-none pr-4 text-right text-[var(--text-dim)] opacity-50">
                {i + 1}
              </span>
              <span className="table-cell whitespace-pre" dangerouslySetInnerHTML={{ __html: highlightLine(line) }} />
            </div>
          ))}
        </code>
      </pre>
    </div>
  )
}
