import { Component, type ErrorInfo, type ReactNode } from 'react'

interface Props {
  children: ReactNode
}

interface State {
  hasError: boolean
  message: string
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, message: '' }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Sortscope crashed:', error, info.componentStack)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex h-screen flex-col items-center justify-center gap-3 bg-[var(--bg)] p-6 text-center text-[var(--text)]">
          <h1 className="font-display text-xl font-semibold">Something went wrong</h1>
          <p className="max-w-md text-sm text-[var(--text-dim)]">{this.state.message}</p>
          <button
            onClick={() => window.location.reload()}
            className="rounded-lg bg-[var(--accent)] px-4 py-2 text-sm font-medium text-[var(--bg)]"
          >
            Reload the app
          </button>
        </div>
      )
    }
    return this.props.children
  }
}
