import { useState } from 'react'
import { ALGORITHM_INFO } from '@/constants/algorithmInfo'
import { useVisualizerStore } from '@/store/useVisualizerStore'
import { CodeViewer } from './CodeViewer'

const TABS = ['Overview', 'Complexity', 'Code'] as const
type Tab = (typeof TABS)[number]

function Pill({ label, tone }: { label: string; tone: 'ok' | 'warn' }) {
  return (
    <span
      className="rounded-full px-2.5 py-1 text-xs font-medium"
      style={{
        background: tone === 'ok' ? 'color-mix(in srgb, var(--sorted) 18%, transparent)' : 'color-mix(in srgb, var(--swap) 18%, transparent)',
        color: tone === 'ok' ? 'var(--sorted)' : 'var(--swap)',
      }}
    >
      {label}
    </span>
  )
}

export function AlgorithmInfoPanel() {
  const algorithm = useVisualizerStore((s) => s.algorithm)
  const meta = ALGORITHM_INFO[algorithm]
  const [tab, setTab] = useState<Tab>('Overview')

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)]">
      <div className="flex items-center justify-between border-b border-[var(--border)] px-5 pt-4">
        <div>
          <h2 className="font-display text-lg font-semibold text-[var(--text)]">{meta.name}</h2>
          <p className="text-xs text-[var(--text-dim)]">{meta.tier} tier</p>
        </div>
        <div className="flex gap-1.5 pb-2">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`focus-ring rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                tab === t ? 'bg-[var(--surface-2)] text-[var(--accent)]' : 'text-[var(--text-dim)] hover:text-[var(--text)]'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="p-5">
        {tab === 'Overview' && (
          <div className="space-y-4">
            <p className="text-sm leading-relaxed text-[var(--text-dim)]">{meta.description}</p>
            <div className="flex flex-wrap gap-2">
              <Pill label={meta.complexity.stable ? 'Stable' : 'Not stable'} tone={meta.complexity.stable ? 'ok' : 'warn'} />
              <Pill label={meta.complexity.inPlace ? 'In-place' : 'Not in-place'} tone={meta.complexity.inPlace ? 'ok' : 'warn'} />
            </div>
            <div>
              <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">
                Practical applications
              </h4>
              <ul className="list-inside list-disc space-y-1 text-sm text-[var(--text)]">
                {meta.applications.map((a) => (
                  <li key={a}>{a}</li>
                ))}
              </ul>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">Advantages</h4>
                <ul className="list-inside list-disc space-y-1 text-sm text-[var(--text)]">
                  {meta.advantages.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">Disadvantages</h4>
                <ul className="list-inside list-disc space-y-1 text-sm text-[var(--text)]">
                  {meta.disadvantages.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {tab === 'Complexity' && (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ['Best case', meta.complexity.best],
              ['Average case', meta.complexity.average],
              ['Worst case', meta.complexity.worst],
              ['Space', meta.complexity.space],
            ].map(([label, value]) => (
              <div key={label} className="rounded-lg border border-[var(--border)] bg-[var(--surface-2)] p-3 text-center">
                <div className="text-[10px] font-semibold uppercase tracking-wide text-[var(--text-dim)]">{label}</div>
                <div className="mt-1 font-mono text-base font-semibold text-[var(--accent)]">{value}</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'Code' && <CodeViewer meta={meta} />}
      </div>
    </div>
  )
}
