import { useStatsStore, favoriteAlgorithm } from '@/store/useStatsStore'
import { ALGORITHM_INFO } from '@/constants/algorithmInfo'
import type { AlgorithmId } from '@/algorithms/types'

export function HistoryStats() {
  const { stats, clear } = useStatsStore()
  const favorite = favoriteAlgorithm(stats)
  const avgMs = stats.executionCount > 0 ? Math.round(stats.totalExecutionMs / stats.executionCount) : 0

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-sm font-semibold text-[var(--text)]">Your history</h3>
        <button
          onClick={clear}
          className="focus-ring text-xs text-[var(--text-dim)] underline decoration-dotted hover:text-[var(--accent)]"
        >
          Clear
        </button>
      </div>
      <dl className="space-y-2 text-sm">
        <div className="flex justify-between">
          <dt className="text-[var(--text-dim)]">Arrays sorted</dt>
          <dd className="font-mono text-[var(--text)]">{stats.totalArraysSorted}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-[var(--text-dim)]">Favorite algorithm</dt>
          <dd className="font-mono text-[var(--text)]">
            {favorite ? ALGORITHM_INFO[favorite as AlgorithmId].name : '—'}
          </dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-[var(--text-dim)]">Largest array sorted</dt>
          <dd className="font-mono text-[var(--text)]">{stats.largestArraySorted || '—'}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-[var(--text-dim)]">Fastest run</dt>
          <dd className="font-mono text-[var(--text)]">
            {stats.fastestExecutionMs !== null ? `${stats.fastestExecutionMs} ms` : '—'}
          </dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-[var(--text-dim)]">Average run time</dt>
          <dd className="font-mono text-[var(--text)]">{avgMs ? `${avgMs} ms` : '—'}</dd>
        </div>
      </dl>
    </div>
  )
}
