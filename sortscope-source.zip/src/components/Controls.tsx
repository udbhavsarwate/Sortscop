import { FiPlay, FiPause, FiSquare, FiRefreshCw, FiShuffle } from 'react-icons/fi'
import { TbArrowsSort, TbSortDescending2 } from 'react-icons/tb'
import { useVisualizerStore } from '@/store/useVisualizerStore'
import { ALGORITHM_INFO, ALGORITHM_ORDER } from '@/constants/algorithmInfo'

function IconButton({
  onClick,
  disabled,
  label,
  children,
}: {
  onClick: () => void
  disabled?: boolean
  label: string
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      className="focus-ring flex items-center justify-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm font-medium text-[var(--text)] transition hover:border-[var(--accent)] hover:text-[var(--accent)] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:border-[var(--border)] disabled:hover:text-[var(--text)]"
    >
      {children}
    </button>
  )
}

export function Controls() {
  const {
    status,
    speed,
    arraySize,
    algorithm,
    setAlgorithm,
    setArraySize,
    setSpeed,
    generateRandomArray,
    shuffleArray,
    reverseArray,
    nearlySortedArray,
    play,
    pause,
    resume,
    stop,
  } = useVisualizerStore()

  const isPlaying = status === 'playing'
  const isPaused = status === 'paused'
  const isDone = status === 'done'
  const isBusy = isPlaying || isPaused

  return (
    <div className="flex flex-col gap-5 rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5">
      <div>
        <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">
          Algorithm
        </label>
        <select
          value={algorithm}
          disabled={isBusy}
          onChange={(e) => setAlgorithm(e.target.value as typeof algorithm)}
          className="focus-ring w-full rounded-lg border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2 text-sm text-[var(--text)] disabled:opacity-50"
        >
          {ALGORITHM_ORDER.map((id) => (
            <option key={id} value={id}>
              {ALGORITHM_INFO[id].name} · {ALGORITHM_INFO[id].tier}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1.5 flex justify-between text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">
            <span>Array size</span>
            <span className="font-mono text-[var(--text)]">{arraySize}</span>
          </label>
          <input
            type="range"
            min={5}
            max={150}
            value={arraySize}
            disabled={isBusy}
            onChange={(e) => setArraySize(Number(e.target.value))}
            className="w-full accent-[var(--accent)] disabled:opacity-50"
          />
        </div>
        <div>
          <label className="mb-1.5 flex justify-between text-xs font-semibold uppercase tracking-wide text-[var(--text-dim)]">
            <span>Speed</span>
            <span className="font-mono text-[var(--text)]">{speed}</span>
          </label>
          <input
            type="range"
            min={1}
            max={100}
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="w-full accent-[var(--accent)]"
          />
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {!isPlaying ? (
          <IconButton onClick={isPaused ? resume : play} label={isPaused ? 'Resume' : 'Play'}>
            <FiPlay /> {isPaused ? 'Resume' : 'Play'}
          </IconButton>
        ) : (
          <IconButton onClick={pause} label="Pause">
            <FiPause /> Pause
          </IconButton>
        )}
        <IconButton onClick={stop} disabled={status === 'idle'} label="Stop">
          <FiSquare /> Stop
        </IconButton>
        <IconButton onClick={() => generateRandomArray()} disabled={isBusy} label="Generate random array">
          <FiRefreshCw /> New
        </IconButton>
        <IconButton onClick={shuffleArray} disabled={isBusy} label="Shuffle array">
          <FiShuffle /> Shuffle
        </IconButton>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <IconButton onClick={reverseArray} disabled={isBusy} label="Reverse sorted array">
          <TbSortDescending2 /> Reverse sorted
        </IconButton>
        <IconButton onClick={nearlySortedArray} disabled={isBusy} label="Nearly sorted array">
          <TbArrowsSort /> Nearly sorted
        </IconButton>
      </div>

      {isDone && (
        <p className="rounded-lg border border-[var(--sorted)]/40 bg-[var(--sorted)]/10 px-3 py-2 text-center text-xs font-medium text-[var(--sorted)]">
          Sort complete
        </p>
      )}
    </div>
  )
}
