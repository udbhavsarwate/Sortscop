import { BarChart } from '@/components/BarChart'
import { Legend } from '@/components/Legend'
import { Controls } from '@/components/Controls'
import { CustomArrayInput } from '@/components/CustomArrayInput'
import { StatsDashboard } from '@/components/StatsDashboard'
import { HistoryStats } from '@/components/HistoryStats'
import { AlgorithmInfoPanel } from '@/components/AlgorithmInfoPanel'

export function VisualizePage() {
  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[320px_1fr]">
      <aside className="flex flex-col gap-5 lg:order-1">
        <Controls />
        <CustomArrayInput />
        <HistoryStats />
      </aside>

      <main className="flex flex-col gap-5 lg:order-2">
        <div className="h-[360px] sm:h-[420px]">
          <BarChart />
        </div>
        <Legend />
        <StatsDashboard />
        <AlgorithmInfoPanel />
      </main>
    </div>
  )
}
