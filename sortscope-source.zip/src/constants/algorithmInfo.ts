import type { AlgorithmId } from '@/algorithms/types'

export interface ComplexityInfo {
  best: string
  average: string
  worst: string
  space: string
  stable: boolean
  inPlace: boolean
}

export interface AlgorithmMeta {
  id: AlgorithmId
  name: string
  tier: 'Basic' | 'Intermediate' | 'Advanced'
  description: string
  complexity: ComplexityInfo
  applications: string[]
  advantages: string[]
  disadvantages: string[]
  code: Record<'javascript' | 'python' | 'java' | 'cpp', string>
}

export const ALGORITHM_ORDER: AlgorithmId[] = [
  'bubble',
  'selection',
  'insertion',
  'merge',
  'quick',
  'heap',
  'shell',
  'counting',
  'radix',
]

export const ALGORITHM_INFO: Record<AlgorithmId, AlgorithmMeta> = {
  bubble: {
    id: 'bubble',
    name: 'Bubble Sort',
    tier: 'Basic',
    description:
      'Repeatedly steps through the list, compares adjacent elements and swaps them if they are in the wrong order. Each pass "bubbles" the largest remaining value to its final position.',
    complexity: { best: 'O(n)', average: 'O(n\u00b2)', worst: 'O(n\u00b2)', space: 'O(1)', stable: true, inPlace: true },
    applications: ['Teaching sorting fundamentals', 'Detecting a nearly-sorted list (best case is linear)'],
    advantages: ['Simple to implement and reason about', 'Stable and in-place', 'Adaptive: fast on nearly sorted input'],
    disadvantages: ['Quadratic time makes it impractical for large datasets', 'Far more swaps than insertion sort on average'],
    code: {
      javascript: `function bubbleSort(arr) {\n  const n = arr.length;\n  for (let i = 0; i < n - 1; i++) {\n    let swapped = false;\n    for (let j = 0; j < n - i - 1; j++) {\n      if (arr[j] > arr[j + 1]) {\n        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];\n        swapped = true;\n      }\n    }\n    if (!swapped) break;\n  }\n  return arr;\n}`,
      python: `def bubble_sort(arr):\n    n = len(arr)\n    for i in range(n - 1):\n        swapped = False\n        for j in range(n - i - 1):\n            if arr[j] > arr[j + 1]:\n                arr[j], arr[j + 1] = arr[j + 1], arr[j]\n                swapped = True\n        if not swapped:\n            break\n    return arr`,
      java: `void bubbleSort(int[] arr) {\n    int n = arr.length;\n    for (int i = 0; i < n - 1; i++) {\n        boolean swapped = false;\n        for (int j = 0; j < n - i - 1; j++) {\n            if (arr[j] > arr[j + 1]) {\n                int temp = arr[j];\n                arr[j] = arr[j + 1];\n                arr[j + 1] = temp;\n                swapped = true;\n            }\n        }\n        if (!swapped) break;\n    }\n}`,
      cpp: `void bubbleSort(vector<int>& arr) {\n    int n = arr.size();\n    for (int i = 0; i < n - 1; i++) {\n        bool swapped = false;\n        for (int j = 0; j < n - i - 1; j++) {\n            if (arr[j] > arr[j + 1]) {\n                swap(arr[j], arr[j + 1]);\n                swapped = true;\n            }\n        }\n        if (!swapped) break;\n    }\n}`,
    },
  },
  selection: {
    id: 'selection',
    name: 'Selection Sort',
    tier: 'Basic',
    description:
      'Divides the list into a sorted and unsorted region, repeatedly selecting the minimum element from the unsorted region and moving it to the end of the sorted region.',
    complexity: { best: 'O(n\u00b2)', average: 'O(n\u00b2)', worst: 'O(n\u00b2)', space: 'O(1)', stable: false, inPlace: true },
    applications: ['Situations where memory writes are expensive (minimizes swaps)', 'Small datasets'],
    advantages: ['At most n swaps, useful when writes are costly', 'Simple and in-place'],
    disadvantages: ['Quadratic in every case, not adaptive', 'Not stable in its typical implementation'],
    code: {
      javascript: `function selectionSort(arr) {\n  const n = arr.length;\n  for (let i = 0; i < n - 1; i++) {\n    let minIdx = i;\n    for (let j = i + 1; j < n; j++) {\n      if (arr[j] < arr[minIdx]) minIdx = j;\n    }\n    if (minIdx !== i) {\n      [arr[i], arr[minIdx]] = [arr[minIdx], arr[i]];\n    }\n  }\n  return arr;\n}`,
      python: `def selection_sort(arr):\n    n = len(arr)\n    for i in range(n - 1):\n        min_idx = i\n        for j in range(i + 1, n):\n            if arr[j] < arr[min_idx]:\n                min_idx = j\n        if min_idx != i:\n            arr[i], arr[min_idx] = arr[min_idx], arr[i]\n    return arr`,
      java: `void selectionSort(int[] arr) {\n    int n = arr.length;\n    for (int i = 0; i < n - 1; i++) {\n        int minIdx = i;\n        for (int j = i + 1; j < n; j++) {\n            if (arr[j] < arr[minIdx]) minIdx = j;\n        }\n        int temp = arr[minIdx];\n        arr[minIdx] = arr[i];\n        arr[i] = temp;\n    }\n}`,
      cpp: `void selectionSort(vector<int>& arr) {\n    int n = arr.size();\n    for (int i = 0; i < n - 1; i++) {\n        int minIdx = i;\n        for (int j = i + 1; j < n; j++) {\n            if (arr[j] < arr[minIdx]) minIdx = j;\n        }\n        swap(arr[minIdx], arr[i]);\n    }\n}`,
    },
  },
  insertion: {
    id: 'insertion',
    name: 'Insertion Sort',
    tier: 'Basic',
    description:
      'Builds the final sorted array one item at a time, taking each new element and inserting it into its correct position among the already-sorted elements to its left.',
    complexity: { best: 'O(n)', average: 'O(n\u00b2)', worst: 'O(n\u00b2)', space: 'O(1)', stable: true, inPlace: true },
    applications: ['Small or nearly-sorted arrays', 'Online sorting (data arrives incrementally)', 'Used as the base case inside hybrid sorts like Timsort'],
    advantages: ['Very fast on small or nearly sorted input', 'Stable, in-place, and adaptive'],
    disadvantages: ['Quadratic on random or reverse-sorted large arrays', 'Many shifting operations for large datasets'],
    code: {
      javascript: `function insertionSort(arr) {\n  for (let i = 1; i < arr.length; i++) {\n    const key = arr[i];\n    let j = i - 1;\n    while (j >= 0 && arr[j] > key) {\n      arr[j + 1] = arr[j];\n      j--;\n    }\n    arr[j + 1] = key;\n  }\n  return arr;\n}`,
      python: `def insertion_sort(arr):\n    for i in range(1, len(arr)):\n        key = arr[i]\n        j = i - 1\n        while j >= 0 and arr[j] > key:\n            arr[j + 1] = arr[j]\n            j -= 1\n        arr[j + 1] = key\n    return arr`,
      java: `void insertionSort(int[] arr) {\n    for (int i = 1; i < arr.length; i++) {\n        int key = arr[i];\n        int j = i - 1;\n        while (j >= 0 && arr[j] > key) {\n            arr[j + 1] = arr[j];\n            j--;\n        }\n        arr[j + 1] = key;\n    }\n}`,
      cpp: `void insertionSort(vector<int>& arr) {\n    for (int i = 1; i < (int)arr.size(); i++) {\n        int key = arr[i];\n        int j = i - 1;\n        while (j >= 0 && arr[j] > key) {\n            arr[j + 1] = arr[j];\n            j--;\n        }\n        arr[j + 1] = key;\n    }\n}`,
    },
  },
  merge: {
    id: 'merge',
    name: 'Merge Sort',
    tier: 'Intermediate',
    description:
      'A divide-and-conquer algorithm that recursively splits the array in half, sorts each half, and merges the two sorted halves back together in linear time.',
    complexity: { best: 'O(n log n)', average: 'O(n log n)', worst: 'O(n log n)', space: 'O(n)', stable: true, inPlace: false },
    applications: ['External sorting (data too large for memory)', 'Sorting linked lists', 'Stable sort requirements, e.g. multi-key sorting'],
    advantages: ['Guaranteed O(n log n) regardless of input order', 'Stable, predictable performance'],
    disadvantages: ['Needs O(n) extra space for the merge step', 'Slower constant factor than quicksort in practice'],
    code: {
      javascript: `function mergeSort(arr) {\n  if (arr.length <= 1) return arr;\n  const mid = Math.floor(arr.length / 2);\n  const left = mergeSort(arr.slice(0, mid));\n  const right = mergeSort(arr.slice(mid));\n  return merge(left, right);\n}\n\nfunction merge(left, right) {\n  const result = [];\n  let i = 0, j = 0;\n  while (i < left.length && j < right.length) {\n    result.push(left[i] <= right[j] ? left[i++] : right[j++]);\n  }\n  return [...result, ...left.slice(i), ...right.slice(j)];\n}`,
      python: `def merge_sort(arr):\n    if len(arr) <= 1:\n        return arr\n    mid = len(arr) // 2\n    left = merge_sort(arr[:mid])\n    right = merge_sort(arr[mid:])\n    return merge(left, right)\n\n\ndef merge(left, right):\n    result, i, j = [], 0, 0\n    while i < len(left) and j < len(right):\n        if left[i] <= right[j]:\n            result.append(left[i]); i += 1\n        else:\n            result.append(right[j]); j += 1\n    return result + left[i:] + right[j:]`,
      java: `void mergeSort(int[] arr, int lo, int hi) {\n    if (lo >= hi) return;\n    int mid = (lo + hi) / 2;\n    mergeSort(arr, lo, mid);\n    mergeSort(arr, mid + 1, hi);\n    merge(arr, lo, mid, hi);\n}\n\nvoid merge(int[] arr, int lo, int mid, int hi) {\n    int[] temp = new int[hi - lo + 1];\n    int i = lo, j = mid + 1, k = 0;\n    while (i <= mid && j <= hi) {\n        temp[k++] = arr[i] <= arr[j] ? arr[i++] : arr[j++];\n    }\n    while (i <= mid) temp[k++] = arr[i++];\n    while (j <= hi) temp[k++] = arr[j++];\n    System.arraycopy(temp, 0, arr, lo, temp.length);\n}`,
      cpp: `void merge(vector<int>& arr, int lo, int mid, int hi) {\n    vector<int> temp(hi - lo + 1);\n    int i = lo, j = mid + 1, k = 0;\n    while (i <= mid && j <= hi)\n        temp[k++] = arr[i] <= arr[j] ? arr[i++] : arr[j++];\n    while (i <= mid) temp[k++] = arr[i++];\n    while (j <= hi) temp[k++] = arr[j++];\n    copy(temp.begin(), temp.end(), arr.begin() + lo);\n}\n\nvoid mergeSort(vector<int>& arr, int lo, int hi) {\n    if (lo >= hi) return;\n    int mid = (lo + hi) / 2;\n    mergeSort(arr, lo, mid);\n    mergeSort(arr, mid + 1, hi);\n    merge(arr, lo, mid, hi);\n}`,
    },
  },
  quick: {
    id: 'quick',
    name: 'Quick Sort',
    tier: 'Intermediate',
    description:
      'A divide-and-conquer algorithm that picks a pivot, partitions the array so smaller elements land left and larger elements land right of it, then recursively sorts each partition.',
    complexity: { best: 'O(n log n)', average: 'O(n log n)', worst: 'O(n\u00b2)', space: 'O(log n)', stable: false, inPlace: true },
    applications: ['General-purpose sorting in most standard libraries', 'Situations needing average-case speed over worst-case guarantees'],
    advantages: ['Excellent average-case performance and cache locality', 'In-place, low memory overhead'],
    disadvantages: ['Worst case O(n\u00b2) on already-sorted or adversarial input', 'Not stable'],
    code: {
      javascript: `function quickSort(arr, lo = 0, hi = arr.length - 1) {\n  if (lo >= hi) return arr;\n  const p = partition(arr, lo, hi);\n  quickSort(arr, lo, p - 1);\n  quickSort(arr, p + 1, hi);\n  return arr;\n}\n\nfunction partition(arr, lo, hi) {\n  const pivot = arr[hi];\n  let i = lo - 1;\n  for (let j = lo; j < hi; j++) {\n    if (arr[j] < pivot) {\n      i++;\n      [arr[i], arr[j]] = [arr[j], arr[i]];\n    }\n  }\n  [arr[i + 1], arr[hi]] = [arr[hi], arr[i + 1]];\n  return i + 1;\n}`,
      python: `def quick_sort(arr, lo=0, hi=None):\n    if hi is None:\n        hi = len(arr) - 1\n    if lo >= hi:\n        return arr\n    p = partition(arr, lo, hi)\n    quick_sort(arr, lo, p - 1)\n    quick_sort(arr, p + 1, hi)\n    return arr\n\n\ndef partition(arr, lo, hi):\n    pivot = arr[hi]\n    i = lo - 1\n    for j in range(lo, hi):\n        if arr[j] < pivot:\n            i += 1\n            arr[i], arr[j] = arr[j], arr[i]\n    arr[i + 1], arr[hi] = arr[hi], arr[i + 1]\n    return i + 1`,
      java: `void quickSort(int[] arr, int lo, int hi) {\n    if (lo >= hi) return;\n    int p = partition(arr, lo, hi);\n    quickSort(arr, lo, p - 1);\n    quickSort(arr, p + 1, hi);\n}\n\nint partition(int[] arr, int lo, int hi) {\n    int pivot = arr[hi];\n    int i = lo - 1;\n    for (int j = lo; j < hi; j++) {\n        if (arr[j] < pivot) {\n            i++;\n            int t = arr[i]; arr[i] = arr[j]; arr[j] = t;\n        }\n    }\n    int t = arr[i + 1]; arr[i + 1] = arr[hi]; arr[hi] = t;\n    return i + 1;\n}`,
      cpp: `int partition(vector<int>& arr, int lo, int hi) {\n    int pivot = arr[hi];\n    int i = lo - 1;\n    for (int j = lo; j < hi; j++) {\n        if (arr[j] < pivot) swap(arr[++i], arr[j]);\n    }\n    swap(arr[i + 1], arr[hi]);\n    return i + 1;\n}\n\nvoid quickSort(vector<int>& arr, int lo, int hi) {\n    if (lo >= hi) return;\n    int p = partition(arr, lo, hi);\n    quickSort(arr, lo, p - 1);\n    quickSort(arr, p + 1, hi);\n}`,
    },
  },
  heap: {
    id: 'heap',
    name: 'Heap Sort',
    tier: 'Intermediate',
    description:
      'Builds a binary max-heap from the array, then repeatedly swaps the root (largest value) with the last element of the heap and shrinks the heap, restoring the heap property each time.',
    complexity: { best: 'O(n log n)', average: 'O(n log n)', worst: 'O(n log n)', space: 'O(1)', stable: false, inPlace: true },
    applications: ['Priority queues', 'Systems needing guaranteed O(n log n) with O(1) extra space'],
    advantages: ['Guaranteed O(n log n) worst case', 'In-place, no extra array needed'],
    disadvantages: ['Not stable', 'Poor cache locality compared to quicksort/merge sort'],
    code: {
      javascript: `function heapSort(arr) {\n  const n = arr.length;\n  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) heapify(arr, n, i);\n  for (let end = n - 1; end > 0; end--) {\n    [arr[0], arr[end]] = [arr[end], arr[0]];\n    heapify(arr, end, 0);\n  }\n  return arr;\n}\n\nfunction heapify(arr, size, root) {\n  let largest = root;\n  const l = 2 * root + 1, r = 2 * root + 2;\n  if (l < size && arr[l] > arr[largest]) largest = l;\n  if (r < size && arr[r] > arr[largest]) largest = r;\n  if (largest !== root) {\n    [arr[root], arr[largest]] = [arr[largest], arr[root]];\n    heapify(arr, size, largest);\n  }\n}`,
      python: `def heap_sort(arr):\n    n = len(arr)\n    for i in range(n // 2 - 1, -1, -1):\n        heapify(arr, n, i)\n    for end in range(n - 1, 0, -1):\n        arr[0], arr[end] = arr[end], arr[0]\n        heapify(arr, end, 0)\n    return arr\n\n\ndef heapify(arr, size, root):\n    largest = root\n    l, r = 2 * root + 1, 2 * root + 2\n    if l < size and arr[l] > arr[largest]:\n        largest = l\n    if r < size and arr[r] > arr[largest]:\n        largest = r\n    if largest != root:\n        arr[root], arr[largest] = arr[largest], arr[root]\n        heapify(arr, size, largest)`,
      java: `void heapSort(int[] arr) {\n    int n = arr.length;\n    for (int i = n / 2 - 1; i >= 0; i--) heapify(arr, n, i);\n    for (int end = n - 1; end > 0; end--) {\n        int t = arr[0]; arr[0] = arr[end]; arr[end] = t;\n        heapify(arr, end, 0);\n    }\n}\n\nvoid heapify(int[] arr, int size, int root) {\n    int largest = root, l = 2 * root + 1, r = 2 * root + 2;\n    if (l < size && arr[l] > arr[largest]) largest = l;\n    if (r < size && arr[r] > arr[largest]) largest = r;\n    if (largest != root) {\n        int t = arr[root]; arr[root] = arr[largest]; arr[largest] = t;\n        heapify(arr, size, largest);\n    }\n}`,
      cpp: `void heapify(vector<int>& arr, int size, int root) {\n    int largest = root, l = 2 * root + 1, r = 2 * root + 2;\n    if (l < size && arr[l] > arr[largest]) largest = l;\n    if (r < size && arr[r] > arr[largest]) largest = r;\n    if (largest != root) {\n        swap(arr[root], arr[largest]);\n        heapify(arr, size, largest);\n    }\n}\n\nvoid heapSort(vector<int>& arr) {\n    int n = arr.size();\n    for (int i = n / 2 - 1; i >= 0; i--) heapify(arr, n, i);\n    for (int end = n - 1; end > 0; end--) {\n        swap(arr[0], arr[end]);\n        heapify(arr, end, 0);\n    }\n}`,
    },
  },
  shell: {
    id: 'shell',
    name: 'Shell Sort',
    tier: 'Advanced',
    description:
      'A generalization of insertion sort that compares elements far apart before comparing nearby elements. It sorts elements at decreasing "gap" intervals, so the array becomes progressively more sorted before a final gap-1 pass.',
    complexity: { best: 'O(n log n)', average: 'O(n^1.3)', worst: 'O(n\u00b2)', space: 'O(1)', stable: false, inPlace: true },
    applications: ['Embedded systems with limited memory (in-place, simple)', 'Medium-sized arrays where a full O(n log n) sort is overkill'],
    advantages: ['Better than insertion sort in practice on medium arrays', 'In-place with low memory footprint'],
    disadvantages: ['Not stable', 'Performance depends heavily on the chosen gap sequence'],
    code: {
      javascript: `function shellSort(arr) {\n  const n = arr.length;\n  for (let gap = Math.floor(n / 2); gap > 0; gap = Math.floor(gap / 2)) {\n    for (let i = gap; i < n; i++) {\n      const temp = arr[i];\n      let j = i;\n      while (j >= gap && arr[j - gap] > temp) {\n        arr[j] = arr[j - gap];\n        j -= gap;\n      }\n      arr[j] = temp;\n    }\n  }\n  return arr;\n}`,
      python: `def shell_sort(arr):\n    n = len(arr)\n    gap = n // 2\n    while gap > 0:\n        for i in range(gap, n):\n            temp = arr[i]\n            j = i\n            while j >= gap and arr[j - gap] > temp:\n                arr[j] = arr[j - gap]\n                j -= gap\n            arr[j] = temp\n        gap //= 2\n    return arr`,
      java: `void shellSort(int[] arr) {\n    int n = arr.length;\n    for (int gap = n / 2; gap > 0; gap /= 2) {\n        for (int i = gap; i < n; i++) {\n            int temp = arr[i];\n            int j = i;\n            while (j >= gap && arr[j - gap] > temp) {\n                arr[j] = arr[j - gap];\n                j -= gap;\n            }\n            arr[j] = temp;\n        }\n    }\n}`,
      cpp: `void shellSort(vector<int>& arr) {\n    int n = arr.size();\n    for (int gap = n / 2; gap > 0; gap /= 2) {\n        for (int i = gap; i < n; i++) {\n            int temp = arr[i];\n            int j = i;\n            while (j >= gap && arr[j - gap] > temp) {\n                arr[j] = arr[j - gap];\n                j -= gap;\n            }\n            arr[j] = temp;\n        }\n    }\n}`,
    },
  },
  counting: {
    id: 'counting',
    name: 'Counting Sort',
    tier: 'Advanced',
    description:
      'A non-comparison sort that counts occurrences of each distinct value, then uses prefix sums of those counts to place every element directly into its final sorted position.',
    complexity: { best: 'O(n + k)', average: 'O(n + k)', worst: 'O(n + k)', space: 'O(n + k)', stable: true, inPlace: false },
    applications: ['Sorting integers within a known, small range', 'A subroutine inside radix sort'],
    advantages: ['Linear time when the value range k is small', 'Stable, simple to implement'],
    disadvantages: ['Impractical when the value range k is much larger than n', 'Only works on discrete keys (integers), not arbitrary comparables'],
    code: {
      javascript: `function countingSort(arr) {\n  const max = Math.max(...arr);\n  const min = Math.min(...arr);\n  const count = new Array(max - min + 1).fill(0);\n  for (const num of arr) count[num - min]++;\n  for (let i = 1; i < count.length; i++) count[i] += count[i - 1];\n  const output = new Array(arr.length);\n  for (let i = arr.length - 1; i >= 0; i--) {\n    output[count[arr[i] - min] - 1] = arr[i];\n    count[arr[i] - min]--;\n  }\n  return output;\n}`,
      python: `def counting_sort(arr):\n    if not arr:\n        return arr\n    lo, hi = min(arr), max(arr)\n    count = [0] * (hi - lo + 1)\n    for num in arr:\n        count[num - lo] += 1\n    for i in range(1, len(count)):\n        count[i] += count[i - 1]\n    output = [0] * len(arr)\n    for num in reversed(arr):\n        count[num - lo] -= 1\n        output[count[num - lo]] = num\n    return output`,
      java: `int[] countingSort(int[] arr) {\n    int max = Arrays.stream(arr).max().getAsInt();\n    int min = Arrays.stream(arr).min().getAsInt();\n    int[] count = new int[max - min + 1];\n    for (int num : arr) count[num - min]++;\n    for (int i = 1; i < count.length; i++) count[i] += count[i - 1];\n    int[] output = new int[arr.length];\n    for (int i = arr.length - 1; i >= 0; i--) {\n        output[--count[arr[i] - min]] = arr[i];\n    }\n    return output;\n}`,
      cpp: `vector<int> countingSort(vector<int>& arr) {\n    int mx = *max_element(arr.begin(), arr.end());\n    int mn = *min_element(arr.begin(), arr.end());\n    vector<int> count(mx - mn + 1, 0);\n    for (int num : arr) count[num - mn]++;\n    for (size_t i = 1; i < count.size(); i++) count[i] += count[i - 1];\n    vector<int> output(arr.size());\n    for (int i = (int)arr.size() - 1; i >= 0; i--) {\n        output[--count[arr[i] - mn]] = arr[i];\n    }\n    return output;\n}`,
    },
  },
  radix: {
    id: 'radix',
    name: 'Radix Sort',
    tier: 'Advanced',
    description:
      'A non-comparison sort that processes integer keys digit by digit, from least significant to most significant, using a stable counting sort as a subroutine at each digit position.',
    complexity: { best: 'O(nk)', average: 'O(nk)', worst: 'O(nk)', space: 'O(n + k)', stable: true, inPlace: false },
    applications: ['Sorting large sets of fixed-width integers or strings', 'Suffix array construction', 'Hardware sorting networks'],
    advantages: ['Linear time relative to number of digits k', 'Stable, no comparisons needed'],
    disadvantages: ['Only applicable to integers or fixed-format keys', 'Extra memory for the counting-sort passes'],
    code: {
      javascript: `function radixSort(arr) {\n  const max = Math.max(...arr);\n  for (let exp = 1; Math.floor(max / exp) > 0; exp *= 10) {\n    arr = countingByDigit(arr, exp);\n  }\n  return arr;\n}\n\nfunction countingByDigit(arr, exp) {\n  const output = new Array(arr.length);\n  const count = new Array(10).fill(0);\n  for (const num of arr) count[Math.floor(num / exp) % 10]++;\n  for (let i = 1; i < 10; i++) count[i] += count[i - 1];\n  for (let i = arr.length - 1; i >= 0; i--) {\n    const digit = Math.floor(arr[i] / exp) % 10;\n    output[--count[digit]] = arr[i];\n  }\n  return output;\n}`,
      python: `def radix_sort(arr):\n    if not arr:\n        return arr\n    max_val = max(arr)\n    exp = 1\n    while max_val // exp > 0:\n        arr = counting_by_digit(arr, exp)\n        exp *= 10\n    return arr\n\n\ndef counting_by_digit(arr, exp):\n    output = [0] * len(arr)\n    count = [0] * 10\n    for num in arr:\n        count[(num // exp) % 10] += 1\n    for i in range(1, 10):\n        count[i] += count[i - 1]\n    for num in reversed(arr):\n        digit = (num // exp) % 10\n        count[digit] -= 1\n        output[count[digit]] = num\n    return output`,
      java: `void radixSort(int[] arr) {\n    int max = Arrays.stream(arr).max().getAsInt();\n    for (int exp = 1; max / exp > 0; exp *= 10) {\n        countingByDigit(arr, exp);\n    }\n}\n\nvoid countingByDigit(int[] arr, int exp) {\n    int[] output = new int[arr.length];\n    int[] count = new int[10];\n    for (int num : arr) count[(num / exp) % 10]++;\n    for (int i = 1; i < 10; i++) count[i] += count[i - 1];\n    for (int i = arr.length - 1; i >= 0; i--) {\n        int digit = (arr[i] / exp) % 10;\n        output[--count[digit]] = arr[i];\n    }\n    System.arraycopy(output, 0, arr, 0, arr.length);\n}`,
      cpp: `void countingByDigit(vector<int>& arr, int exp) {\n    vector<int> output(arr.size());\n    int count[10] = {0};\n    for (int num : arr) count[(num / exp) % 10]++;\n    for (int i = 1; i < 10; i++) count[i] += count[i - 1];\n    for (int i = (int)arr.size() - 1; i >= 0; i--) {\n        int digit = (arr[i] / exp) % 10;\n        output[--count[digit]] = arr[i];\n    }\n    arr = output;\n}\n\nvoid radixSort(vector<int>& arr) {\n    int mx = *max_element(arr.begin(), arr.end());\n    for (int exp = 1; mx / exp > 0; exp *= 10) countingByDigit(arr, exp);\n}`,
    },
  },
}
