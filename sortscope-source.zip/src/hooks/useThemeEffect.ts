import { useEffect } from 'react'
import { THEMES } from '@/constants/themes'
import { useVisualizerStore } from '@/store/useVisualizerStore'

export function useThemeEffect() {
  const theme = useVisualizerStore((s) => s.theme)

  useEffect(() => {
    const root = document.documentElement
    const vars = THEMES[theme].vars
    Object.entries(vars).forEach(([key, value]) => {
      root.style.setProperty(key, value)
    })
  }, [theme])
}
