import { useEffect, useMemo, useState } from 'react'
import { sortFunctions, type AlgorithmId, type SortStep } from '@/algorithms'

interface Highlights {
  compare: number[]
  swap: number[]
  sorted: Set<number>
  pivot: number[]
  current: number[]
  merge: number[]
}

const emptyHighlights = (): Highlights => ({ compare: [], swap: [], sorted: new Set(), pivot: [], current: [], merge: [] })

function speedToDelay(speed: number): number {
  const clamped = Math.min(100, Math.max(1, speed))
  const t = (clamped - 1) / 99
  return Math.round(500 - t * 498)
}

/**
 * Drives a single sort playback independent of the global visualizer store.
 * All visible values (array, highlights, counters) are derived from the
 * recorded step list up to `cursor`, so the only mutable state is the
 * cursor position itself — advanced by a plain effect-driven timer.
 */
export function useSortPlayer(algorithm: AlgorithmId, initialArray: number[], speed: number) {
  const resetKey = `${algorithm}|${initialArray.join(',')}`
  const [key, setKey] = useState(resetKey)
  const [steps, setSteps] = useState<SortStep[]>([])
  const [cursor, setCursor] = useState(0)
  const [running, setRunning] = useState(false)
  const [startedAt, setStartedAt] = useState<number | null>(null)
  const [finishedAt, setFinishedAt] = useState<number | null>(null)

  if (resetKey !== key) {
    setKey(resetKey)
    setSteps([])
    setCursor(0)
    setRunning(false)
    setStartedAt(null)
    setFinishedAt(null)
  }

  useEffect(() => {
    if (!running) return
    if (cursor >= steps.length) return
    const id = window.setTimeout(() => {
      setCursor((c) => {
        const next = c + 1
        if (next >= steps.length) {
          setRunning(false)
          setFinishedAt(Date.now())
        }
        return next
      })
    }, speedToDelay(speed))
    return () => window.clearTimeout(id)
  }, [running, cursor, steps.length, speed])

  const derived = useMemo(() => {
    const h = emptyHighlights()
    let array = initialArray
    let comparisons = 0
    let swaps = 0
    for (let i = 0; i < Math.min(cursor, steps.length); i++) {
      const step = steps[i]
      if (step.array) array = step.array
      if (step.kind === 'compare') comparisons++
      if (step.kind === 'swap') swaps++
      if (step.kind === 'sorted') step.indices.forEach((idx) => h.sorted.add(idx))
    }
    const last = steps[Math.min(cursor, steps.length) - 1]
    if (last) {
      switch (last.kind) {
        case 'compare':
          h.compare = last.indices
          break
        case 'swap':
          h.swap = last.indices
          break
        case 'pivot':
          h.pivot = last.indices
          break
        case 'merge':
          h.merge = last.indices
          break
        case 'current':
        case 'heap':
        case 'overwrite':
          h.current = last.indices
          break
      }
    }
    return { array, highlights: h, comparisons, swaps }
  }, [steps, cursor, initialArray])

  const status: 'idle' | 'playing' | 'done' = finishedAt !== null ? 'done' : running ? 'playing' : 'idle'
  const elapsedMs = startedAt && finishedAt ? finishedAt - startedAt : 0

  function play() {
    if (steps.length === 0) {
      const result = sortFunctions[algorithm](initialArray)
      setSteps(result.steps)
      setCursor(0)
    }
    setFinishedAt(null)
    setStartedAt(Date.now())
    setRunning(true)
  }

  return { array: derived.array, highlights: derived.highlights, comparisons: derived.comparisons, swaps: derived.swaps, status, elapsedMs, play }
}
