import { describe, it, expect } from 'vitest'
import { highlightLine } from '@/utils/highlight'

describe('highlightLine', () => {
  it('wraps keywords in a token span', () => {
    expect(highlightLine('function foo() {')).toContain('tok-kw')
  })

  it('wraps numeric literals in a token span', () => {
    expect(highlightLine('let x = 42;')).toContain('tok-num')
  })

  it('wraps string literals in a token span', () => {
    expect(highlightLine("const s = 'hello';")).toContain('tok-str')
  })

  it('wraps line comments in a token span', () => {
    expect(highlightLine('// a comment')).toContain('tok-comment')
  })

  it('escapes HTML-sensitive characters', () => {
    expect(highlightLine('if (a < b) {}')).toContain('&lt;')
  })
})
