import { describe, it, expect } from 'vitest'
import { resolveBarColor, type BarHighlights } from '@/utils/barColor'

function highlights(overrides: Partial<BarHighlights> = {}): BarHighlights {
  return {
    compare: [],
    swap: [],
    sorted: new Set<number>(),
    pivot: [],
    current: [],
    merge: [],
    ...overrides,
  }
}

describe('resolveBarColor', () => {
  it('returns the default bar color with no highlights', () => {
    expect(resolveBarColor(0, highlights())).toBe('var(--bar)')
  })

  it('prioritizes swap over sorted for the same index', () => {
    const h = highlights({ swap: [2], sorted: new Set([2]) })
    expect(resolveBarColor(2, h)).toBe('var(--swap)')
  })

  it('prioritizes pivot over compare', () => {
    const h = highlights({ pivot: [4], compare: [4] })
    expect(resolveBarColor(4, h)).toBe('var(--pivot)')
  })

  it('reflects sorted state once no higher-priority highlight applies', () => {
    const h = highlights({ sorted: new Set([1, 2, 3]) })
    expect(resolveBarColor(1, h)).toBe('var(--sorted)')
    expect(resolveBarColor(5, h)).toBe('var(--bar)')
  })

  it('reflects a compare highlight for both compared indices', () => {
    const h = highlights({ compare: [3, 7] })
    expect(resolveBarColor(3, h)).toBe('var(--compare)')
    expect(resolveBarColor(7, h)).toBe('var(--compare)')
  })
})
