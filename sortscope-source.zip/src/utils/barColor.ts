export interface BarHighlights {
  compare: number[]
  swap: number[]
  sorted: Set<number>
  pivot: number[]
  current: number[]
  merge: number[]
}

/**
 * Resolves the CSS variable color for a bar at `index`, given the current
 * highlight state. Priority order matters: a swap in progress should always
 * read as a swap even if the same index is also marked "sorted" from a
 * previous pass.
 */
export function resolveBarColor(index: number, h: BarHighlights): string {
  if (h.swap.includes(index)) return 'var(--swap)'
  if (h.pivot.includes(index)) return 'var(--pivot)'
  if (h.merge.includes(index)) return 'var(--accent-2)'
  if (h.compare.includes(index)) return 'var(--compare)'
  if (h.current.includes(index)) return 'var(--accent)'
  if (h.sorted.has(index)) return 'var(--sorted)'
  return 'var(--bar)'
}
