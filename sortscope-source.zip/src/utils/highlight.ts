const KEYWORDS = [
  'function', 'return', 'if', 'else', 'for', 'while', 'let', 'const', 'var', 'break', 'continue',
  'def', 'while', 'in', 'range', 'None', 'True', 'False', 'not', 'and', 'or',
  'void', 'int', 'boolean', 'new', 'public', 'private', 'static', 'class', 'this',
  'vector', 'auto', 'include', 'using', 'namespace', 'struct',
]

const KEYWORD_RE = new RegExp(`\\b(${KEYWORDS.join('|')})\\b`, 'g')

export function highlightLine(line: string): string {
  const escaped = line
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')

  const commentMatch = escaped.match(/(\/\/.*$)|(#.*$)/)
  let code = escaped
  let comment = ''
  if (commentMatch && commentMatch.index !== undefined) {
    code = escaped.slice(0, commentMatch.index)
    comment = escaped.slice(commentMatch.index)
  }

  code = code
    .replace(/(&quot;.*?&quot;|'.*?'|`.*?`)/g, '<span class="tok-str">$1</span>')
    .replace(/\b(\d+(\.\d+)?)\b/g, '<span class="tok-num">$1</span>')
    .replace(KEYWORD_RE, '<span class="tok-kw">$1</span>')

  return comment ? `${code}<span class="tok-comment">${comment}</span>` : code
}
