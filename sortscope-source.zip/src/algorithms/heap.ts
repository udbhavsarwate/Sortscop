import type { AlgorithmResult, SortStep } from './types'

export function heapSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0
  const n = arr.length

  function heapify(size: number, root: number) {
    let largest = root
    const left = 2 * root + 1
    const right = 2 * root + 2
    steps.push({ kind: 'heap', indices: [root] })

    if (left < size) {
      comparisons++
      steps.push({ kind: 'compare', indices: [left, largest] })
      if (arr[left] > arr[largest]) largest = left
    }
    if (right < size) {
      comparisons++
      steps.push({ kind: 'compare', indices: [right, largest] })
      if (arr[right] > arr[largest]) largest = right
    }
    if (largest !== root) {
      ;[arr[root], arr[largest]] = [arr[largest], arr[root]]
      swaps++
      steps.push({ kind: 'swap', indices: [root, largest], array: [...arr] })
      heapify(size, largest)
    }
  }

  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
    heapify(n, i)
  }
  for (let end = n - 1; end > 0; end--) {
    ;[arr[0], arr[end]] = [arr[end], arr[0]]
    swaps++
    steps.push({ kind: 'swap', indices: [0, end], array: [...arr] })
    steps.push({ kind: 'sorted', indices: [end] })
    heapify(end, 0)
  }
  steps.push({ kind: 'sorted', indices: Array.from({ length: n }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
