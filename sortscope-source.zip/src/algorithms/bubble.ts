import type { AlgorithmResult, SortStep } from './types'

export function bubbleSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0
  const n = arr.length

  for (let i = 0; i < n - 1; i++) {
    let swappedThisPass = false
    for (let j = 0; j < n - i - 1; j++) {
      comparisons++
      steps.push({ kind: 'compare', indices: [j, j + 1] })
      if (arr[j] > arr[j + 1]) {
        ;[arr[j], arr[j + 1]] = [arr[j + 1], arr[j]]
        swaps++
        swappedThisPass = true
        steps.push({ kind: 'swap', indices: [j, j + 1], array: [...arr] })
      }
    }
    steps.push({ kind: 'sorted', indices: [n - i - 1] })
    if (!swappedThisPass) {
      const remaining = []
      for (let k = 0; k < n - i - 1; k++) remaining.push(k)
      if (remaining.length) steps.push({ kind: 'sorted', indices: remaining })
      break
    }
  }
  steps.push({ kind: 'sorted', indices: Array.from({ length: n }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
