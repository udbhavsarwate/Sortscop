import type { AlgorithmResult, SortStep } from './types'

export function mergeSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0

  function merge(lo: number, mid: number, hi: number) {
    const left = arr.slice(lo, mid + 1)
    const right = arr.slice(mid + 1, hi + 1)
    steps.push({ kind: 'range', indices: [lo, hi] })
    let i = 0
    let j = 0
    let k = lo
    while (i < left.length && j < right.length) {
      comparisons++
      steps.push({ kind: 'compare', indices: [lo + i, mid + 1 + j] })
      if (left[i] <= right[j]) {
        arr[k] = left[i]
        i++
      } else {
        arr[k] = right[j]
        j++
      }
      swaps++
      steps.push({ kind: 'merge', indices: [k], array: [...arr] })
      k++
    }
    while (i < left.length) {
      arr[k] = left[i]
      steps.push({ kind: 'merge', indices: [k], array: [...arr] })
      i++
      k++
    }
    while (j < right.length) {
      arr[k] = right[j]
      steps.push({ kind: 'merge', indices: [k], array: [...arr] })
      j++
      k++
    }
    const sortedRange = []
    for (let x = lo; x <= hi; x++) sortedRange.push(x)
    steps.push({ kind: 'sorted', indices: sortedRange })
  }

  function sort(lo: number, hi: number) {
    if (lo >= hi) return
    const mid = Math.floor((lo + hi) / 2)
    sort(lo, mid)
    sort(mid + 1, hi)
    merge(lo, mid, hi)
  }

  sort(0, arr.length - 1)
  steps.push({ kind: 'sorted', indices: Array.from({ length: arr.length }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
