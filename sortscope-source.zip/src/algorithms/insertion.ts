import type { AlgorithmResult, SortStep } from './types'

export function insertionSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0
  const n = arr.length

  steps.push({ kind: 'sorted', indices: [0] })
  for (let i = 1; i < n; i++) {
    const key = arr[i]
    let j = i - 1
    steps.push({ kind: 'current', indices: [i] })
    while (j >= 0) {
      comparisons++
      steps.push({ kind: 'compare', indices: [j, j + 1] })
      if (arr[j] > key) {
        arr[j + 1] = arr[j]
        swaps++
        steps.push({ kind: 'overwrite', indices: [j + 1], values: [arr[j]], array: [...arr] })
        j--
      } else {
        break
      }
    }
    arr[j + 1] = key
    steps.push({ kind: 'overwrite', indices: [j + 1], values: [key], array: [...arr] })
    const sortedRange = []
    for (let k = 0; k <= i; k++) sortedRange.push(k)
    steps.push({ kind: 'sorted', indices: sortedRange })
  }
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
