import type { AlgorithmResult, SortStep } from './types'

export function selectionSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0
  const n = arr.length

  for (let i = 0; i < n - 1; i++) {
    let minIdx = i
    steps.push({ kind: 'current', indices: [i] })
    for (let j = i + 1; j < n; j++) {
      comparisons++
      steps.push({ kind: 'compare', indices: [minIdx, j] })
      if (arr[j] < arr[minIdx]) {
        minIdx = j
        steps.push({ kind: 'current', indices: [minIdx] })
      }
    }
    if (minIdx !== i) {
      ;[arr[i], arr[minIdx]] = [arr[minIdx], arr[i]]
      swaps++
      steps.push({ kind: 'swap', indices: [i, minIdx], array: [...arr] })
    }
    steps.push({ kind: 'sorted', indices: [i] })
  }
  steps.push({ kind: 'sorted', indices: Array.from({ length: n }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
