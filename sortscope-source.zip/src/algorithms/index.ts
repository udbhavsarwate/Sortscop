import { bubbleSort } from './bubble'
import { selectionSort } from './selection'
import { insertionSort } from './insertion'
import { mergeSort } from './merge'
import { quickSort } from './quick'
import { heapSort } from './heap'
import { shellSort } from './shell'
import { countingSort } from './counting'
import { radixSort } from './radix'
import type { AlgorithmId, SortFn } from './types'

export const sortFunctions: Record<AlgorithmId, SortFn> = {
  bubble: bubbleSort,
  selection: selectionSort,
  insertion: insertionSort,
  merge: mergeSort,
  quick: quickSort,
  heap: heapSort,
  shell: shellSort,
  counting: countingSort,
  radix: radixSort,
}

export * from './types'
