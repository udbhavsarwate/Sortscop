import type { AlgorithmResult, SortStep } from './types'

export function countingSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  const comparisons = 0
  let swaps = 0
  const n = arr.length
  if (n === 0) return { steps: [{ kind: 'done', indices: [] }], comparisons, swaps }

  const max = Math.max(...arr)
  const min = Math.min(...arr)
  const range = max - min + 1
  const count = new Array(range).fill(0)

  for (let i = 0; i < n; i++) {
    count[arr[i] - min]++
    steps.push({ kind: 'current', indices: [i] })
  }
  for (let i = 1; i < range; i++) {
    count[i] += count[i - 1]
  }
  const output = new Array(n).fill(0)
  for (let i = n - 1; i >= 0; i--) {
    const pos = count[arr[i] - min] - 1
    output[pos] = arr[i]
    count[arr[i] - min]--
    swaps++
  }
  for (let i = 0; i < n; i++) {
    arr[i] = output[i]
    steps.push({ kind: 'overwrite', indices: [i], values: [arr[i]], array: [...arr] })
  }
  steps.push({ kind: 'sorted', indices: Array.from({ length: n }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
