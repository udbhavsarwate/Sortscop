import type { AlgorithmResult, SortStep } from './types'

export function radixSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  const comparisons = 0
  let swaps = 0
  const n = arr.length
  if (n === 0) return { steps: [{ kind: 'done', indices: [] }], comparisons, swaps }

  const max = Math.max(...arr)
  let exp = 1

  while (Math.floor(max / exp) > 0) {
    const output = new Array(n).fill(0)
    const count = new Array(10).fill(0)

    for (let i = 0; i < n; i++) {
      const digit = Math.floor(arr[i] / exp) % 10
      count[digit]++
      steps.push({ kind: 'current', indices: [i] })
    }
    for (let i = 1; i < 10; i++) count[i] += count[i - 1]

    for (let i = n - 1; i >= 0; i--) {
      const digit = Math.floor(arr[i] / exp) % 10
      output[count[digit] - 1] = arr[i]
      count[digit]--
      swaps++
    }
    for (let i = 0; i < n; i++) {
      arr[i] = output[i]
      steps.push({ kind: 'overwrite', indices: [i], values: [arr[i]], array: [...arr] })
    }
    exp *= 10
  }
  steps.push({ kind: 'sorted', indices: Array.from({ length: n }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
