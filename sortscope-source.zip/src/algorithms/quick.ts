import type { AlgorithmResult, SortStep } from './types'

export function quickSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0
  const sortedSet = new Set<number>()

  function markSorted(idx: number) {
    sortedSet.add(idx)
    steps.push({ kind: 'sorted', indices: [idx] })
  }

  function partition(lo: number, hi: number): number {
    const pivot = arr[hi]
    steps.push({ kind: 'pivot', indices: [hi] })
    let i = lo - 1
    for (let j = lo; j < hi; j++) {
      comparisons++
      steps.push({ kind: 'compare', indices: [j, hi] })
      if (arr[j] < pivot) {
        i++
        if (i !== j) {
          ;[arr[i], arr[j]] = [arr[j], arr[i]]
          swaps++
          steps.push({ kind: 'swap', indices: [i, j], array: [...arr] })
        }
      }
    }
    ;[arr[i + 1], arr[hi]] = [arr[hi], arr[i + 1]]
    swaps++
    steps.push({ kind: 'swap', indices: [i + 1, hi], array: [...arr] })
    markSorted(i + 1)
    return i + 1
  }

  function sort(lo: number, hi: number) {
    if (lo > hi) return
    if (lo === hi) {
      markSorted(lo)
      return
    }
    steps.push({ kind: 'range', indices: [lo, hi] })
    const p = partition(lo, hi)
    sort(lo, p - 1)
    sort(p + 1, hi)
  }

  sort(0, arr.length - 1)
  steps.push({ kind: 'sorted', indices: Array.from({ length: arr.length }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
