import { describe, it, expect } from 'vitest'
import { sortFunctions } from '@/algorithms'
import type { AlgorithmId } from '@/algorithms/types'

const ALGORITHMS: AlgorithmId[] = [
  'bubble',
  'selection',
  'insertion',
  'merge',
  'quick',
  'heap',
  'shell',
  'counting',
  'radix',
]

function isSorted(arr: number[]): boolean {
  for (let i = 1; i < arr.length; i++) {
    if (arr[i - 1] > arr[i]) return false
  }
  return true
}

function finalArrayFromSteps(input: number[], steps: ReturnType<typeof sortFunctions.bubble>['steps']) {
  let arr = [...input]
  for (const step of steps) {
    if (step.array) arr = step.array
  }
  return arr
}

describe('sorting algorithms', () => {
  const cases: number[][] = [
    [],
    [1],
    [2, 1],
    [5, 4, 3, 2, 1],
    [1, 2, 3, 4, 5],
    [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5],
    [10, 10, 10, 10],
    Array.from({ length: 100 }, () => Math.floor(Math.random() * 500)),
  ]

  for (const algorithm of ALGORITHMS) {
    describe(algorithm, () => {
      for (const [i, input] of cases.entries()) {
        it(`sorts case #${i} (n=${input.length}) correctly`, () => {
          // radix/counting sort assume non-negative integers, satisfied by our cases
          const { steps, comparisons, swaps } = sortFunctions[algorithm](input)
          const result = finalArrayFromSteps(input, steps)
          const expected = [...input].sort((a, b) => a - b)

          expect(result).toEqual(expected)
          expect(isSorted(result)).toBe(true)
          expect(comparisons).toBeGreaterThanOrEqual(0)
          expect(swaps).toBeGreaterThanOrEqual(0)
        })
      }

      it('does not mutate the input array reference', () => {
        const input = [5, 3, 1, 4, 2]
        const snapshot = [...input]
        sortFunctions[algorithm](input)
        expect(input).toEqual(snapshot)
      })
    })
  }
})
