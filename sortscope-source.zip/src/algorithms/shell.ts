import type { AlgorithmResult, SortStep } from './types'

export function shellSort(input: number[]): AlgorithmResult {
  const arr = [...input]
  const steps: SortStep[] = []
  let comparisons = 0
  let swaps = 0
  const n = arr.length

  let gap = Math.floor(n / 2)
  while (gap > 0) {
    for (let i = gap; i < n; i++) {
      const temp = arr[i]
      let j = i
      steps.push({ kind: 'current', indices: [i] })
      while (j >= gap) {
        comparisons++
        steps.push({ kind: 'compare', indices: [j - gap, j] })
        if (arr[j - gap] > temp) {
          arr[j] = arr[j - gap]
          swaps++
          steps.push({ kind: 'overwrite', indices: [j], values: [arr[j]], array: [...arr] })
          j -= gap
        } else {
          break
        }
      }
      arr[j] = temp
      steps.push({ kind: 'overwrite', indices: [j], values: [temp], array: [...arr] })
    }
    gap = Math.floor(gap / 2)
  }
  steps.push({ kind: 'sorted', indices: Array.from({ length: n }, (_, i) => i) })
  steps.push({ kind: 'done', indices: [] })
  return { steps, comparisons, swaps }
}
