export type StepKind =
  | 'compare'
  | 'swap'
  | 'overwrite'
  | 'sorted'
  | 'pivot'
  | 'current'
  | 'merge'
  | 'heap'
  | 'range'
  | 'done'

export interface SortStep {
  kind: StepKind
  indices: number[]
  values?: number[]
  array?: number[]
  note?: string
}

export interface AlgorithmResult {
  steps: SortStep[]
  comparisons: number
  swaps: number
}

export type SortFn = (input: number[]) => AlgorithmResult

export type AlgorithmId =
  | 'bubble'
  | 'selection'
  | 'insertion'
  | 'merge'
  | 'quick'
  | 'heap'
  | 'shell'
  | 'counting'
  | 'radix'
